package ua.com.juja.core;

import java.util.Arrays;

public class BubbleSorter {
    public static void sort(int[] arr) {
        for (int barrier = 0; barrier <  arr.length ; barrier++) {
            for (int index = arr.length - 1; index > barrier; index--) {
//                System.out.println(arr[index - 1] + " -- " + arr[index] );
                if (arr[index-1] > arr[index ]) {
                    int tmp = arr[index - 1];
                    arr[index - 1] = arr[index];
                    arr[index] = tmp;
                }
            }
        }
    }
}
