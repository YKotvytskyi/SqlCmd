package ua.com.juja.core;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello!");
        int res[] =  lookFor(new int[]{0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0});
//        int res[] =  lookFor(new int[]{1000});
//        for (int val:res) {
//            System.out.println(val);
//        }
        int arr[] = new int[]{1, 3, 1, 101, 2,2, 6, 4, 5,1000,1000};
//        InsertionSorter.searchTest();
//        return;
        System.out.println(Arrays.toString(arr));
//        //BubbleSorter.sort(arr);
        InsertionSorter.Sort(arr);
        System.out.println(Arrays.toString(arr));
//        System.out.println(Arrays.toString(arr));
    }

    public static int[] lookFor(int[] array) {
        int i0 = 0, j0 = 0, len0 = 0, j = 0;
        if (array.length == 0) {
            return new  int[]{};
        }
        if ((array.length == 1) && (array[0]>0)) {
            return new int[]{0,0};
        }
        boolean first = array[0] <= 0;
        boolean last = true;
        for (int i=0; i < array.length; i++) {
            boolean negative = (array[i]<=0);
            if ((negative || (i == array.length-1)) ){
                if (!last) continue;
                last = false;
                int len = i - j;
                if (len>len0){
                    len0 = len;
                    if (negative) {
                        i0 = i-1;
                    } else {
                        i0 = i;
                    }
                    j0 = j;
                    first = true;
                }
            }
            else {
                if (first) {
                    j = i;
                    first = false;
                    last = true;
                }
            }
        }
        if (i0 == 0 ) {
            return  new int[]{};
        }
        return new int[]{j0,i0};
    }
}
