package ua.com.juja.core;

/*
 * This program finds and prints on the screen all
 * permutations of the "algorithm" string. The program uses recursion.
 */

class A  {

//    A(){
//
//        System.out.println("A()");
//    }

//    A(int i){
//        System.out.println("A(int)");
//    }

};

class B extends A {


    B(int i){
        System.out.println("B(int)");
    }

};


public class Test{
    public static void main(String arg[]){
        new B(5);
    }

}