package ua.com.juja.core;

import java.util.Arrays;

public class InsertionSorter {
    public static void oldSort(int[] arr) {
        for (int k = 1; k < arr.length; k++) {
            int newElement = arr[k];
            int location = k - 1;
            while (location >= 0 && arr[location] > newElement) {
                arr[location + 1] = arr[location];
                location--;
            }
            arr[location + 1] = newElement;
        }
    }

    public static void Sort(int[] arr) {
        for (int k = 1; k < arr.length; k++) {
            int newElement = arr[k];
            int destination = Arrays.binarySearch(arr, 0, k , newElement);
            if (destination < 0 ) destination = - destination - 1;
            if (destination == k ) {
                continue;
            }
            System.arraycopy(arr,destination,arr,destination + 1,k-destination);
            arr[destination] = newElement;

        }
    }

    public static void searchTest() {
        int[] arr = new int[] {1, 3, 5, 7, 10, 16};
//        int pos = Arrays.binarySearch(arr,0, arr.length,5);
//        int element = 8;
        for (int element = 0; element < 18; element++ ){
            int pos = Arrays.binarySearch(arr,element);
            int first = pos;
            int last = pos;
            if (pos< 0) {
                if (first == -1) {
                    first = 0;
                    last = 0;
                } else  {
                    first = -1*first - 2;
                    last = -1*last - 1;
                }
            }
            if (last > arr.length -1  ) last = arr.length - 1;
            System.out.println(arr[first] + " -- " + element + " -- " + arr[last]);
        }
    }

}
