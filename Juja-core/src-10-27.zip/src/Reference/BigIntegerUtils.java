package Reference;

import java.math.BigInteger;

public class BigIntegerUtils {

    public static void main(String[] args){


//        BigInteger k = new BigInteger("256")
//                .add(new BigInteger("64"))
//                .add(new BigInteger("16"))
//                .add(new BigInteger("4"))
//                .add(new BigInteger("1"));

        BigInteger k = BigInteger.ZERO;

        for (int i = 1; i <= 100; i++) {
            k = k.add(new BigInteger("2").pow(10 * i - 1));
        }

        String expected = "";
        for (int i = 0; i < 100; i++) {
            expected += "1000000000";
        }

        String actual = BigIntegerUtils.toBitStr(k);
        System.out.println(expected + "\r\n"+actual);

//        System.out.println(toBitStr(k));
    }

    public static String toBitStr(BigInteger arg) {
        if (arg.equals(BigInteger.ZERO))
            return "0";
        String result = "";
        byte decimal[] = arg.toByteArray();
        result +=  Integer.toBinaryString(decimal[0]);
        if (result.equals("0"))
            result = "";
        for (int i = 1; i < decimal.length ; i++) {
            String digit = Integer.toBinaryString(decimal[i]);
            result +=  ("00000000" + digit).substring(digit.length());
        }
        return result;
    }
}